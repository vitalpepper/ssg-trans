<?php return array (
  'statamic/ssg' => 
  array (
    'id' => 'statamic/ssg',
    'slug' => NULL,
    'editions' => 
    array (
    ),
    'marketplaceId' => 713,
    'marketplaceSlug' => 'ssg',
    'marketplaceUrl' => 'https://statamic.com/addons/statamic/ssg',
    'marketplaceSellerSlug' => 'statamic',
    'isCommercial' => false,
    'latestVersion' => '3.1.1',
    'version' => '3.1.1',
    'namespace' => 'Statamic\\StaticSite',
    'autoload' => 'src',
    'provider' => 'Statamic\\StaticSite\\ServiceProvider',
    'name' => 'Static Site Generator',
    'url' => NULL,
    'description' => 'Generate static sites with Statamic.',
    'developer' => NULL,
    'developerUrl' => NULL,
    'email' => NULL,
  ),
);